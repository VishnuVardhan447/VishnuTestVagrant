import com.fasterxml.jackson.databind.ObjectMapper;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.junit.Assert;

import javax.xml.ws.Response;
import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class MyStepdefs<UserAccount> {
    ResponseSpecification responseSpecification;
    TeamNumbers teamNumbers;
    RequestSpecification request;
    Response response;
    String jsonRequest = "";
    ObjectMapper mapperObj = new ObjectMapper();

    @Given("I have an authenticated {string}")
    public void iHaveAnAuthenticated(String TeamName) {
        teamNumbers =new TeamNumbers();
        teamNumbers.setTeamName(TeamName);
        teamNumbers.setLocation("Bangalore");
        teamNumbers.setNameplayer("PlayerName");
        teamNumbers.setCountry("Country");
        teamNumbers.setRole("Role");
        teamNumbers.setPriceinCrores("PriceinCrores");
    }


    @And("I add default header details to the request headers")
    public void iAddDefaultHeaderDetailsToTheRequestHeaders() {
        Map<String,String> Header=new HashMap<String,String>();
        Header.put("Content-Type","application/json");

    }

    @And("I enter {string} and {string} in request body")
    public void iEnterAndInRequestBody(String arg0, String arg1) {
        HashMap<String,String> body=new HashMap<>();
        body.put("name", teamNumbers.getTeamName());
        body.put("location", teamNumbers.getLocation());
        body.put("Playername", teamNumbers.getNameplayer());
        body.put("Country",teamNumbers.getCountry());
        body.put("Role",teamNumbers.getRole());
        body.put("PriceinCrores",teamNumbers.getPriceinCrores());
        jsonRequest = mapperObj.writeValueAsString(body);
        System.out.println(jsonRequest);

    }

    @When("I enter {string}to the {string}")
    public void iEnterToThe(String arg0, String arg1) {
        responseSpecification= new ResponseSpecBuilder().expectContentType(ContentType.JSON).build();
        request= given().spec(requestInstance())
                .body(jsonRequest);
        response= (Response) request.when().post().then().spec(responseSpecification).extract().response();
        System.out.println("The status code: " + response.getStatusCode());
    }

    private RequestSpecification requestInstance() {
    }

    @Then("I verify response code is {int}")
    public void iVerifyResponseCodeIs(int arg0) {
        System.out.println("The status code: " + response.getStatusCode());
        Assert.assertTrue(response.getStatusCode() == code);
    }



}
