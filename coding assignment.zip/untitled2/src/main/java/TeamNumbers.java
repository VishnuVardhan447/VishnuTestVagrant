import lombok.Data;

@Data
public class TeamNumbers {
    private String TeamName;
    private String Location;
    private String Nameplayer;
    private String Country;
    private String Role;
    private String PriceinCrores;
    public TeamNumbers(){

    }


}
